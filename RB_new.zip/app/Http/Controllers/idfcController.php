<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class IdfcController extends Controller
{
    public function idfc(){
		
	      return view('idfc');	
	}
}
