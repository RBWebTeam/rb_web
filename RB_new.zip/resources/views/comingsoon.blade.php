@include('layout.header')
<div id="fh5co-hero">
	<div class="container" id="elem">
	<div class="col-md-12 pad centeralign" style="margin:104px 30px 30px -46px"   >
	<center>
<img src=" {{URL::to('images/coming.png')}}" class="img-responsive" >

 <div class="error-actions">
                    <a href="{{URL::to('/')}}" class="btn btn-primary btn-lg"><span class="glyphicon glyphicon-home"></span>
                        Take Me Home </a><a href="{{URL::to('contact-us')}}" class="btn btn-default btn-lg"><span class="glyphicon glyphicon-envelope"></span> Contact Support </a>
                </div>

</center>


</div>
</div>
</div>
@include('layout.footer')
@include('layout.script')