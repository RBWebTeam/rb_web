@include('layout.header')

	




<div class="container bs-docs-container"> 
<div class=col-md-8 role=main> 

<div style="height: 150px;width: 100%;"></div>
   <?php for ($i=0; $i <5 ; $i++) { ?>
<div class="row" style="position: relative; padding-bottom: 30px;border-top: 1px solid #E2E2E2; padding-top: 10px; font-family: "Helvetica Neue", Helvetica, Arial, sans-serif; font-size: 13px;
  font-style: normal;
  font-variant: normal;
  font-weight: 400;
  line-height: 14.4px;"> 
 
 
   <h3 id="headings" class="heading_" >Should I take home loan instead of paying huge rent for pg in Hyderabad?</h3> 

      <figure class=highlight>If you went to or are going to a top school like MIT, Harvard, Columbia, Berkeley, Stanford, Cornell, Caltech, Wharton, Princeton, Yale, Brown, what is your studying method?

Could you please give me advice on how to study the best possible way (especially for math classes)? How do you get good gra... <a href="#">(more)</a>
</figure>
  
<div class="row">
  <div class="col-md-1"></div>
   <div class="col-md-2"><a href="#">Answer(0)</a></div>
  <div class="col-md-2"><button type="button" data-toggle="collapse" data-target="#Comment">Comment</button></div>
  <div class="col-md-2"><button type="button" data-toggle="collapse" data-target="#Share">Share</button> </div>

  <div class="tags">home loan</div>
 <div class="tags">personal loan</div>
</div>

  <div id="Comment" class="collapse" style="background-color: #F6F6F6">
    Lorem ipsum dolor sit amet, consectetur adipisicing elit,
    sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
  </div>
  




  <div id="Share" class="collapse" style="background-color: #F6F6F6">
    Lorem ipsum dolor sit amet, consectetur adipisicing elit,
    sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
  </div>
  
  </div>

   <?php  } ?>
<!--    <figure class=highlight><pre><code class=language-html data-lang=html><span class=cp>&lt;!DOCTYPE html&gt;</span>
<span class=nt>&lt;html</span> <span class=na>lang=</span><span class=s>"en"</span><span class=nt>&gt;</span>

</code>
</pre>
</figure> -->




</div>

</div>




<style type="text/css">
  .tags{position: relative;
    display: inline-block;
    padding: .4em .5em;
    margin: 2px 2px 2px 0;
    font-size: 11px;
    line-height: 1;
    white-space: nowrap;
    text-decoration: none;
    text-align: center;
    border-width: 1px;
    border-style: solid;
    border-radius: 0;
    transition: all .15s ease-in-out;}

    .heading_{
       font-size: 19px;
    color: #333;
    letter-spacing: -0.5px;
    line-height: 1.25;
    font-weight: bold;
   
    letter-spacing: -1px;
    
    }


</style>








	
@include('layout.footer')
@include('layout.script')