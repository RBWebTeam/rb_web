@include('layout.header')
	<div id="fh5co-hero">

	<div class="animate-box">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-left fh5co-heading animate-box fadeInUp animated">
				<p class="text-left"><a href="{{URL::to('/')}}">Home</a>/Compare</p>
					<h2>Compare</h2>
					</div>				
				<div class="col-md-12">
					<div class="row pad11 white-bg comp-pg">
  <div class="table-responsive">
<table width="100%" border="1" class="table-bordered">
  <tr>
    <td>&nbsp;</td>
    <td><div class="img-c"><img src="images/axis.jpg"  src="{{URL::to('images/icon1.png')}}" alt="axis-img" width="100" height="30"></div></td>
    <td><div class="img-c"><img src="images/axis.jpg" width="100" height="30"></div></td>
    <td><div class="img-c"><img src="images/axis.jpg" width="100" height="30"></div></td>
  </tr>
  <tr>
    <td><h4>Loan Amount</h4></td>
    <td>750000</td>
    <td>750000</td>
    <td>750000</td>
  </tr>
  <tr>
    <td><h4>Rate</h4></td>
    <td>15.5</td>
    <td>13.5</td>
    <td>14.5</td>
  </tr>
  <tr>
    <td><h4>EMI</h4></td>
    <td>2000</td>
    <td>1500</td>
    <td>1400</td>
  </tr>
  <tr>
    <td><h4>Processing Fee</h4></td>
    <td>1000</td>
    <td>1500</td>
    <td>0</td>
  </tr>
  <tr>
    <td><h4>Pre closed Fee</h4></td>
    <td>2%</td>
    <td>3%</td>
    <td>1%</td>
  </tr>
  <tr>
    <td><h4>Partial Pre Payment fee</h4></td>
    <td>2000</td>
    <td>3000</td>
    <td>1000</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
  <tr>
    <td>&nbsp;</td>
    <td><a href="#">Know More</a></td>
    <td><a href="#">Know More</a></td>
    <td><a href="#">Konw More</a></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><a href="#" class="btn btn-primary btn-outline">Apply Now</a></td>
    <td><a href="#" class="btn btn-primary btn-outline">Apply Now</a></td>
    <td><a href="#" class="btn btn-primary btn-outline">Apply Now</a></td>
  </tr>
</table>
</div>
					</div>
				</div>
			</div>
		</div>	
	</div>

	
	</div>
@include('layout.footer')
@include('layout.script')


