<a href="https://embedtwitterwidget.com/">twitter on every website!</a>
<a href=" https://youtubeembedcode.com/"> generate youtube code quick and easy</a>