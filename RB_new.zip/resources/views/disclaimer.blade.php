@include('layout.header')
<div class="container" id="fh5co-hero">
<div id="fh5co-page">

	<div class="fh5co-contact animate-box">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-left fh5co-heading animate-box fadeInUp animated">
					<h2>Disclaimer</h2>
					</div>				
				<div class="col-md-12">
					<div class="row pad11 white-bg comp-pg about-bg">

			   <p>RupeeBoss intends to provide clear information about loans and insurance products and services. The information and data are generic in nature. Our efforts are to offer accurate and responsible data. We are not responsible for any sort of discrepancies.</p>
<p>There is no purpose of violating any copyright or intellectual copyrights issue. All information provided on the portal RupeeBoss is subject to the discretion of the same and is likely to change without any notice. Though, any changes in public utility will be communicated immediately in our portal.</p>
<p>We have tried to maintain high standards in quality, clarity and accuracy of the material posted on the portal. RupeeBoss is not legally responsible for the same in any matter what so ever. Employees, partners and associated staff of RupeeBoss are not accountable for any loss, harm or damage occurring due to usage of information from the portal. Customers are advised to use their own discretion in such matters. It is important to understand that loans and insurance is a subject matter of solicitation and market risks. It is the responsibility of the customer to understand the limitations of loans and insurance policies and the risks involved, we take no liability in such cases.</p>
<p>Read the subject documents carefully. The information provided on the portal is of financial, loans, insurance and legal purposes. It is a mutual understanding that customers association with the portal will be at the customer's preference and risk.</p>
<p>Visitors to this website/portal and every third party is hereby informed that the owners of this website/portal, viz., Rupeeboss Financial Services Pvt. Ltd, are not the agents or intermediaries of the loan provider and insurers, whose products are dealt with in this website/portal. They are also not the sub-agents or sub-intermediaries of the agents and intermediaries of the respective loan provider and insurers. Though endeavour is made to make correct policy/product comparisons, quotes, features, etc., based on the information provided by the loan provider and insurers or its agents or intermediaries, it is made abundantly clear that Rupeeboss Financial Services Pvt. Ltd, its directors, shareholders, officers and employees and rupeeboss.com are in no way responsible to or liable for any one for his/her loan and investment, and every prospect/ investor/policyholder shall be solely responsible for the consequences of his/her decision.</p>
					</div>
				</div>
			</div>
		</div>	
	</div>

	
	
	
	</div>
	
	
	</div>
@include('layout.footer')
@include('layout.script')

