<img src="http://www.rupeeboss.com/images/logo.png">
<h3>Dear Customer,<h3><br>

Thank you very much for choosing Rupeeboss Financial Services for your financial needs. Your loan application has been successfully submitted.<br> Your Password is <span style="color: red">{{$data}}.</span> <br>
Please change your password immediately after login.<br><br>

<h3>Regards,<br><br>

Help Desk Team<br>
RupeeBoss Financial Services Pvt. Ltd.<br>
Address : 2th Floor-The Centrium, Phoenix Marketcity Mall,<br>
Kurla (West) Mumbai - 400 070<br>
Contact :  1800-267-629-6</h3>
                