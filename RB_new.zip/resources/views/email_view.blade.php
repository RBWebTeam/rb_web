<h1>Welcome to www.rupeeboss.com</h1>
<p>{{$data}}</p>
