				<img src="http://www.rupeeboss.com/images/logo.png">
				<h3>Dear Customer,<h3><br>

                Thank you very much for choosing Rupeeboss Financial Services for your financial needs. Your loan application has been successfully submitted. Your reference number is {{$data}}. Please quote this in all your communication with us. Our credit team will now review your documents take your application forward. We will get back to you within 24 hours.<br><br>


                <h3>Regards,<br><br>

                Help Desk Team<br>
                RupeeBoss Financial Services Pvt. Ltd.<br>
                Address : 2th Floor-The Centrium, Phoenix Marketcity Mall,<br>
                Kurla (West) Mumbai - 400 070<br>
                Contact : 9820030969</h3>
                