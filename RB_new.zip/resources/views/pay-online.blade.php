@include('layout.header')
<div class="container" id="fh5co-hero">

	<div id="fh5co-page">

	<div class="fh5co-contact animate-box">
		<div class="container">
			<div class="row">

               <h2>Pay Online</h2>
                  <div class="col-md-12">
					<div class="row pad11 pad">
               
			    <div class="col-md-3"></div>
				<div class="col-md-6">
				<div class="pay-row1 box-shadow">
                <div class="col-md-6">
				<label>Name</label>
				<input type="text" />
                </div>
				<div class="col-md-6">
				<label>Mobile No.</label>
				<input type="text" />
				</div>
				<div class="col-md-6">
				<label>Email Id.</label>
				<input type="text" />
				</div>
				<div class="col-md-6">
				<label>Product</label>
				<Select class="drop-arr">
				   <option>Personal Loan</option>
				</select>
				</div>
				<div class="col-md-6">
				<label>Cost</label>
				<input type="text" />
			    </div>

				<div class="col-md-12">
				<a href="#" class="pay-submit-btn">CONFIRM</a>
				</div>
				</div>
				</div>


					</div>
				</div>
			</div>
		</div>	
	</div>

	
	
	
	
	
	
	</div>
	
	
</div>
@include('layout.footer')
@include('layout.script')

