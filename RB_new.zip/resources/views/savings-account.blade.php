@include('layout.header')
<br>
<div class="container" id="fh5co-hero">
<div class="col-md-12 text-left fh5co-heading animate-box fadeInUp animated">
					<h2>Savings Account</h2>
					</div>
        <img src="{{URL::to('images/idfc/1.jpg')}}" alt="IDFC" title="IDFC" class="img-responsive"/>
	    <img src="{{URL::to('images/idfc/2.jpg')}}" alt="Why We Are Different" title="Why We Are Different" class="img-responsive"/>
	    <img src="{{URL::to('images/idfc/3.jpg')}}" alt="Service Philosophy" title="Service Philosophy" class="img-responsive"/>
	    <img src="{{URL::to('images/idfc/4.jpg')}}" alt="Spot Account Opening" title="Spot Account Opening" class="img-responsive"/>
	    <img src="{{URL::to('images/idfc/5.jpg')}}" alt="Redifined Service Through Banker" title="Redifined Service Through Banker" class="img-responsive"/>
	    <img src="{{URL::to('images/idfc/6.jpg')}}" alt="Redifined Service" title="Redifined Service" class="img-responsive"/>
	    <img src="{{URL::to('images/idfc/7.jpg')}}" alt="Saves Cost" title="Saves Cost" class="img-responsive"/>
	    <img src="{{URL::to('images/idfc/8.jpg')}}" alt="Deposits" title="Deposits" class="img-responsive"/>
	    <img src="{{URL::to('images/idfc/9.jpg')}}" alt="Visa Signature Debit Card" title="Visa Signature Debit Card" class="img-responsive"/>
	    <img src="{{URL::to('images/idfc/10.jpg')}}" alt="Simple Internet Banking" title="Simple Internet Banking" class="img-responsive"/>
	    <img src="{{URL::to('images/idfc/11.jpg')}}" alt="Simple Mobile Banking" title="Simple Mobile Banking" class="img-responsive"/>
	    <img src="{{URL::to('images/idfc/12.jpg')}}"  alt="Thank You" title="Thank You" class="img-responsive"/>

</div>
<br>
@include('layout.footer')
@include('layout.script')

