<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SME :: Thank You</title>
<style>
 body {font-family:Arial, Helvetica, sans-serif;}
 h1 {color:#3d90c5; font-size:60px; text-align:center;margin:0px;padding:0px;}
 p { text-align:center; color:#666;padding:0px 70px;}
 .main {width: 60%; margin: 0 auto;padding: 20px; border: 16px solid #e7e7e7;margin-top: 10px;background: #f8f8f8;}
 .lnk {text-align:center;text-decoration:none;}
 .logo img {margin:0 auto; text-align:center;display: -webkit-box;
padding: 20px;}
 </style>
</head>

<body>
<div class="logo"><a href="http://www.rupeeboss.com">
<img src="http://www.rupeeboss.com/images/logo.png" alt="Rupeeboss.com " title="Rupeeboss.com " width="160" height="47"></a>
</div>
<div class="main">

 
<h3>Thank you for submitting your details our executives will reach you soon in two working days.</h3>
<p> <a href="http://www.rupeeboss.com" class="lnk">www.rupeeboss.com</a></p>
</div>
</body>
</html>
