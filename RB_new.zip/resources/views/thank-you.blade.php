@include('layout.header')
<div id="fh5co-hero">
	<div class="container" id="elem">
	<div class="col-md-12 pad centeralign"  >
<center><img src="{{URL::to('images/thank-you.jpg')}}" class="img-responsive" ></center>
</div>
</div>
</div>
@include('layout.footer')
@include('layout.script')