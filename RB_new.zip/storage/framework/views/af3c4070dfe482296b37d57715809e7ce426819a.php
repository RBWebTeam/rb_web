<?php echo $__env->make('layout.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="fh5co-hero">
	<div class="container" id="elem">
	<div class="col-md-12 pad centeralign"  >
<center><img src="<?php echo e(URL::to('images/thank-you.jpg')); ?>" class="img-responsive" ></center>
</div>
</div>
</div>
<?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layout.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>